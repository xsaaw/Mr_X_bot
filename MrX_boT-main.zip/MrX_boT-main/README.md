# MaSterX BOT

A telegram bot to check credit cards. written in py.
make sure to update proxies!!


## Click below deploy button to host it on heroku.
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

## Deploy on Okteto

[![Develop on Okteto](https://okteto.com/develop-okteto.svg)](https://cloud.okteto.com/deploy)

You can contact me [tg](https://telegram.me/xxsaawxx) my tg channel [here](https://t.me/Freemiumairdrop)
Feel free to donate me ..
